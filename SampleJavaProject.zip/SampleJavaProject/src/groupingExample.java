import org.testng.annotations.Test;

public class groupingExample {

    @Test (groups = {"Sanity"})
    void test1(){
        System.out.println("This is test 1...");
    }

    @Test (groups = {"Functionality"})
    void test2(){
        System.out.println("This is test 2...");
    }

    @Test (groups = {"Regression"})
    void test3(){
        System.out.println("This is test 3...");
    }

    @Test (groups = {"Sanity","Regression"})
    void test4(){
        System.out.println("This is test 4...");
    }
}
