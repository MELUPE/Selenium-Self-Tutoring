import org.testng.annotations.Test;

public class secondtestcase {
    @Test(priority = 1)
    void setup()
    {
        System.out.println("Opening Browser");
    }

    @Test(priority =3)
    void searchCustomer()
    {
        System.out.println("This is search customer");
    }

    @Test(priority =2)
    void addCustomer()
    {
        System.out.println("This is add customer");
    }

    @Test(priority = 4)
    void close()
    {
        System.out.println("Closing browser");
    }
}
