import org.testng.annotations.*;

public class TC1 {

    @BeforeClass
    void beforeClass()
    {
        System.out.println("This will execute before class");
    }

    @BeforeMethod
    void beforeMethods()
    {
        System.out.println("This will execute before every method");
    }

    @BeforeTest
    void beforeTest()
    {
        System.out.println("This will execute before test");
    }

    @BeforeSuite
    void beforeSuite()
    {
        System.out.println("This will execute before every Test Suite");
    }

    @Test
    void test1()
    {
        System.out.println("This is test 1");
    }
    @Test
    void test2()
    {
        System.out.println("This is test 2");
    }

    @AfterMethod
    void afterMethod()
    {
        System.out.println("This will execute after method");
    }

    @AfterClass
    void afterClass()
    {
        System.out.println("This will execute after class");
    }

    @AfterTest
    void afterTest()
    {
        System.out.println("This will execute after test");
    }

    @AfterSuite
    void afterSuite()
    {
        System.out.println("This will execute before every Test Suite");
    }

}
