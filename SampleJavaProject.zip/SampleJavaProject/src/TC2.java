import org.testng.annotations.*;

public class TC2 {

    @BeforeClass
    void beforeClass()
    {
        System.out.println("This will execute before class");
    }

    @BeforeMethod
    void beforeMethods()
    {
        System.out.println("This will execute before every method");
    }

    @Test
    void test3()
    {
        System.out.println("This is test 3");
    }
    @Test
    void test4()
    {
        System.out.println("This is test 4");
    }

    @AfterMethod
    void afterMethod()
    {
        System.out.println("This will execute after method");
    }

    @AfterClass
    void afterClass()
    {
        System.out.println("This will execute after class");
    }
}
