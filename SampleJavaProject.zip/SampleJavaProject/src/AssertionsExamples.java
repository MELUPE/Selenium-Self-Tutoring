import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class AssertionsExamples {

    WebDriver driver;
    @BeforeClass
    void setup()
    {
        driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/");
    }

    @Test (priority = 2)
    void  logo()
    {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        WebElement image = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//*[@id='app']//img")
                )
        );
    }
    @Test (priority = 1)
    void homePageTitle()
    {
        String title = driver.getTitle();
        Assert.assertEquals("OrangeHRM", title);
    }

    @AfterClass
    void quit()
    {
        driver.quit();
    }
}
